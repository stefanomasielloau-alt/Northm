// Shared editable-grid engine for the North V2 Strategy module mockups.
// Wraps each page's top-level content blocks (KPI rows, panels, charts) as
// GridStack items so Stef can drag to reposition and drag a corner to
// stretch/shrink, toggled on via the "Edit layout" button in the top bar.
// Layout is saved per page in localStorage (opt-in, per Stef's round-4 answer).
(function () {
  function initPageGrid(pageKey) {
    var gridEl = document.getElementById('page-grid');
    if (!gridEl || typeof GridStack === 'undefined') return;
    var storageKey = 'north-v2-layout-' + pageKey;

    // Give every item a small drag handle strip (only visible/active in edit mode)
    // so dragging doesn't fight with clicking links, reading tables, etc. The
    // drag handle and the panel's original content are combined into one
    // wrapper (.gs-inner) so we have a single element whose natural height we
    // can measure below.
    // Captured before GridStack.init() touches the DOM: GridStack reorders
    // grid-stack-item elements in the DOM to match its own internal node
    // order as part of placing them, so a later querySelectorAll no longer
    // reflects the page's authored (intended) order. This array is what the
    // masonry pass below walks instead, so "next item in the layout" always
    // means "next panel as Stef designed the page," not "wherever GridStack
    // has since moved it to."
    var items = Array.prototype.slice.call(gridEl.querySelectorAll('.grid-stack-item'));
    items.forEach(function (item) {
      var c = item.querySelector('.grid-stack-item-content');
      if (c && !c.querySelector('.gs-inner')) {
        var wrap = document.createElement('div');
        wrap.className = 'gs-inner';
        var h = document.createElement('div');
        h.className = 'gs-item-handle';
        h.innerHTML = '<span>⠿⠿ drag to move · drag corner to resize</span>';
        wrap.appendChild(h);
        while (c.firstChild) {
          wrap.appendChild(c.firstChild);
        }
        c.appendChild(wrap);
      }
    });

    var grid = GridStack.init(
      {
        column: 12,
        cellHeight: 12,
        margin: 10,
        float: true,
        animate: false, // GridStack CSS-transitions every move/resize by default (300ms), which
        // means a height read back immediately after grid.update() below is a mid-transition
        // value, not the settled one — the layout math needs updates to apply instantly.
        disableDrag: true,
        disableResize: true,
        handle: '.gs-item-handle',
        resizable: { handles: 'e, se, s, sw, w' },
      },
      gridEl
    );

    // Guards the 'change' listener below so that laying out the DEFAULT
    // page (restoring a save, or running the masonry pass) never itself
    // counts as "Stef rearranged something" and gets written back to
    // localStorage — only a real user drag/resize should ever save.
    var settled = false;

    // Restore a saved layout if Stef rearranged this page before.
    var restoredSaved = false;
    try {
      var saved = JSON.parse(localStorage.getItem(storageKey) || 'null');
      if (saved && saved.length) {
        grid.load(saved);
        restoredSaved = true;
      }
    } catch (e) {
      /* ignore malformed saved layout */
    }
    if (restoredSaved) {
      settled = true;
    }

    // On a fresh (non-restored) layout, work out every item's real content
    // height ourselves and lay the whole page out in one deterministic pass
    // — a simple two-column masonry packer we run in plain JS — rather than
    // leaning on GridStack's own collision/placement logic to reconcile
    // heights it doesn't know yet. That async reconciliation (via repeated
    // update()/compact() calls) turned out to reliably scramble which item
    // ends up in which slot once a page has more than one row of paired
    // half-width panels. Computing the full x/y/h layout up front and
    // applying each value once removes the ambiguity entirely. A restored
    // (Stef-arranged) layout is left exactly as saved instead.
    if (!restoredSaved) {
      requestAnimationFrame(function () {
        var unitPx = 12 + 10; // cellHeight + margin — only used as a starting guess
        function initialGuess(px) {
          return Math.max(1, Math.ceil(px / unitPx));
        }
        // GridStack's actual rendered px-per-unit doesn't match a simple
        // h*cellHeight+(h-1)*margin formula closely enough to trust blindly
        // (measured empirically: a fixed h consistently rendered shorter
        // than that formula predicts), so rather than hard-code the wrong
        // constant, fitHeight() sets a guess, measures what GridStack
        // actually rendered, and scales up until the item is tall enough
        // to show its full content without clipping.
        function fitHeight(el, targetPx) {
          var content = el.querySelector('.grid-stack-item-content');
          var h = initialGuess(targetPx);
          for (var guard = 0; guard < 10; guard++) {
            grid.update(el, { h: Math.min(h, 400) });
            var got = content.getBoundingClientRect().height;
            if (got >= targetPx - 1) break;
            // Grow by the remaining shortfall converted to grid units (never
            // multiplicatively) — a got of 0 on an early pass must not blow h
            // up to something absurd, it should just add one more guess-sized
            // step and try again.
            h += Math.max(1, Math.ceil((targetPx - got) / unitPx));
          }
          return Math.min(h, 400);
        }
        var els = items; // the pre-init DOM order captured above
        var cursorUnits = 0; // whole grid rows only — no px/unit mixing, so nothing can drift into overlap
        var i = 0;
        while (i < els.length) {
          var el = els[i];
          var w = parseInt(el.getAttribute('gs-w'), 10) || 12;
          var inner = el.querySelector('.gs-inner');
          var innerH = inner ? inner.getBoundingClientRect().height : 0;
          if (w >= 12) {
            grid.update(el, { x: 0, y: cursorUnits, w: w, h: initialGuess(innerH) });
            var h = fitHeight(el, innerH);
            cursorUnits += h;
            i += 1;
          } else {
            var next = els[i + 1];
            var nextInner = next ? next.querySelector('.gs-inner') : null;
            var nextInnerH = nextInner ? nextInner.getBoundingClientRect().height : innerH;
            var rowY = cursorUnits;
            grid.update(el, { x: 0, y: rowY, w: w, h: initialGuess(innerH) });
            var h1 = fitHeight(el, innerH);
            if (next) {
              grid.update(next, { x: 6, y: rowY, w: w, h: initialGuess(nextInnerH) });
              var h2 = fitHeight(next, nextInnerH);
              cursorUnits += Math.max(h1, h2);
            } else {
              cursorUnits += h1;
            }
            i += next ? 2 : 1;
          }
        }
        settled = true;
      });
    }

    grid.on('change', function () {
      if (!settled) return;
      try {
        localStorage.setItem(storageKey, JSON.stringify(grid.save(false)));
      } catch (e) {
        /* storage unavailable — layout just won't persist */
      }
    });

    var toggleBtn = document.getElementById('edit-layout-toggle');
    var resetBtn = document.getElementById('reset-layout-btn');
    var editing = false;

    function setEditing(on) {
      editing = on;
      document.body.classList.toggle('edit-mode', on);
      grid.enableMove(on);
      grid.enableResize(on);
      if (toggleBtn) {
        toggleBtn.textContent = on ? '✓ Done editing' : '⠿ Edit layout';
        toggleBtn.classList.toggle('active', on);
      }
    }

    if (toggleBtn) {
      toggleBtn.addEventListener('click', function () {
        setEditing(!editing);
      });
    }
    if (resetBtn) {
      resetBtn.addEventListener('click', function () {
        try {
          localStorage.removeItem(storageKey);
        } catch (e) {
          /* ignore */
        }
        location.reload();
      });
    }
  }

  window.initPageGrid = initPageGrid;
})();
